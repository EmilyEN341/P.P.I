/*Função contador*/
let contador = document.getElementById("contador");
let valor = 0;

function contar(){
    contador.innerHTML = valor;
    valor ++;
}