console.log("Hello");

let a = Number(prompt("A"));
let b = Number(prompt("B"));
console.log(a+b);